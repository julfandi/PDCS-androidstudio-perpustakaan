package com.example.perpustakaan

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.EditText
import android.widget.ListView
import android.widget.TextWatcher
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.ListAdapter

data class ListItem(val id_buku: Int, val judul: String, val author: String, val cover: String)

    class MainActivity : AppCompatActivity() {

        private lateinit var listView: ListView

        private lateinit var listAdapter: ListAdapter

        private lateinit var searchEditText: EditText

        private val allItems = arrayListOf(
            ListItem(),
            ListItem(),
            ListItem(),
            ListItem(
                id_buku = 4,
                judul = "Forest Trail",
                author = "2022",
                cover = ""
            )
        )

        private var filteredItems = ArrayList(allItems)

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            enableEdgeToEdge()
            setContentView(R.layout.activity_main)

            listView = findViewById(R.id.listview)
            searchEditText = findViewById(R.id.searchEditText)

            listAdapter = ListAdapter(this, filteredItems)
            listView.adapter = listAdapter

            searchEditText.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?,start: Int, count: Int, after: Int) {}

                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    filterList(s.toString())
                }

                override fun afterTextChanged(s: Editable?) {}
            })

            ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
                val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
                insets
        }
    }

        private fun filterList(query: String) {
            val filteredList = if (query.isEmpty()) {
                allItems
            } else {
                allItems.filter { item ->
                    item.judul.contains(query, ignoreCase = true) ||
                            item.author.contains(query, ignoreCase = true)
                }
            }
            listAdapter.updateList(ArrayList(filteredList))
        }


//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        enableEdgeToEdge()
//        setContentView(R.layout.activity_main)
//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
//            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
//            insets
//        }
//    }
}